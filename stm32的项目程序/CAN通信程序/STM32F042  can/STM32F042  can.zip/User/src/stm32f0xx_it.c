/**
  ******************************************************************************
  * @file    stm32_it.c
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    31-January-2014
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and peripherals
  *          interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */


/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_it.h"
#include "iso_usart1.h"
#include "iso_can.h"
extern __IO uint32_t ret;

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M0 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}


/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}


/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
} 

/**
  * @brief  This function handles USB FS Handler.
  * @param  None
  * @retval None
  */


/******************************************************************************/
/*                 STM32F0xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f072.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */

void DMA1_Channel2_3_IRQHandler(void)
{
			if(DMA_GetFlagStatus(DMA1_FLAG_TC2)!= RESET)	//�ж�ͨ��2�������
			{
					DMA_ClearFlag(DMA1_FLAG_TC2);//���ͨ��2������ɱ�־
					DMA_Cmd(DMA1_Channel2, DISABLE);
					DMA_Cmd(DMA1_Channel3, DISABLE);
					DMA1_Channel3->CNDTR=Max_DMA_USART_Buffer_Len;
					DMA_Cmd(DMA1_Channel3, ENABLE);
					//printf("\r\n DMA����:%s\r\n", g_DMA_USART_Buffer);
					printf("\r\n DMA���ݷ�����:%d\r\n", DMA_GetCurrDataCounter(DMA1_Channel2));//�õ���ǰ��ʣ����ٸ�����
					printf("USART1 Tx DMA�������\r\n");
					
		  }

}

void CEC_CAN_IRQHandler(void)
{
	uint8_t cnt=0;
  CanRxMsg RxMessage;
	RxMessage.StdId=0x00;
	RxMessage.ExtId=0x00;
	RxMessage.IDE=0;
	RxMessage.DLC=0;
	RxMessage.FMI=0;
  
	if( CAN_GetITStatus(CAN, CAN_IT_FMP0) == SET )
  {
		
    CAN_Receive(CAN, CAN_FIFO0, &RxMessage);
		if((RxMessage.ExtId==0x1234)  && 
			 (RxMessage.IDE==CAN_ID_EXT))
		{
			for(cnt=0;cnt<RxMessage.DLC;cnt++)
			{
				* pReceiveBuffer=RxMessage.Data[cnt];
				pReceiveBuffer++;
			}
			Receive_Buffer_Len +=RxMessage.DLC;
			CAN_FIFORelease(CAN,CAN_FIFO0);
			printf("\r\n CAN Receive Buffer==%s,RxMessage.DLC==%d\r\n",\
							pReceiveBuffer-RxMessage.DLC,Receive_Buffer_Len);
		}
		CAN_ClearITPendingBit(CAN,CAN_IT_FMP0);
  }
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

