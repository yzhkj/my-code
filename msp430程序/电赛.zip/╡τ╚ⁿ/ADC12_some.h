#ifndef __ADC12_SOME_H__
#define __ADC12_SOME_H__

#include <msp430x14x.h>

unsigned int ADC12A0=0,ADC12A1=0,ADC12A2=0;

void ADC12_init(void);

#endif
